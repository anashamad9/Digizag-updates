"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Send, Globe } from "lucide-react"

interface Message {
  id: string
  content: string
  role: "user" | "assistant"
  timestamp: Date
}

const translations = {
  en: {
    title: "راصد",
    placeholder: "Message راصد...",
    send: "Send",
    language: "العربية",
    welcome: "Hello! I'm راصد, your AI assistant. How can I help you today?",
    examples: ["What can you help me with?", "Tell me about your features", "How do you work?"],
  },
  ar: {
    title: "راصد",
    placeholder: "اكتب رسالة لراصد...",
    send: "إرسال",
    language: "English",
    welcome: "مرحباً! أنا راصد، مساعدك الذكي. كيف يمكنني مساعدتك اليوم؟",
    examples: ["بماذا يمكنك مساعدتي؟", "أخبرني عن ميزاتك", "كيف تعمل؟"],
  },
}

export default function ChatbotPage() {
  const [messages, setMessages] = useState<Message[]>([])
  const [input, setInput] = useState("")
  const [language, setLanguage] = useState<"en" | "ar">("en")
  const [isLoading, setIsLoading] = useState(false)

  const t = translations[language]
  const isRTL = language === "ar"

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!input.trim() || isLoading) return

    const userMessage: Message = {
      id: Date.now().toString(),
      content: input,
      role: "user",
      timestamp: new Date(),
    }

    setMessages((prev) => [...prev, userMessage])
    setInput("")
    setIsLoading(true)

    try {
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          messages: [...messages, userMessage],
          language,
        }),
      })

      if (!response.ok) throw new Error("Failed to get response")

      const reader = response.body?.getReader()
      if (!reader) throw new Error("No reader available")

      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        content: "",
        role: "assistant",
        timestamp: new Date(),
      }

      setMessages((prev) => [...prev, assistantMessage])

      const decoder = new TextDecoder()
      let done = false

      while (!done) {
        const { value, done: readerDone } = await reader.read()
        done = readerDone

        if (value) {
          const chunk = decoder.decode(value)
          const lines = chunk.split("\n")

          for (const line of lines) {
            if (line.startsWith("0:")) {
              try {
                const data = JSON.parse(line.slice(2))
                if (data.type === "text-delta") {
                  assistantMessage.content += data.textDelta
                  setMessages((prev) =>
                    prev.map((msg) =>
                      msg.id === assistantMessage.id ? { ...msg, content: assistantMessage.content } : msg,
                    ),
                  )
                }
              } catch (e) {
                // Ignore parsing errors
              }
            }
          }
        }
      }
    } catch (error) {
      console.error("Error:", error)
      const errorMessage: Message = {
        id: (Date.now() + 1).toString(),
        content:
          language === "ar" ? "عذراً، حدث خطأ. يرجى المحاولة مرة أخرى." : "Sorry, an error occurred. Please try again.",
        role: "assistant",
        timestamp: new Date(),
      }
      setMessages((prev) => [...prev, errorMessage])
    } finally {
      setIsLoading(false)
    }
  }

  const handleExampleClick = (example: string) => {
    setInput(example)
    setTimeout(() => {
      const form = document.querySelector("form")
      if (form) {
        form.dispatchEvent(new Event("submit", { cancelable: true, bubbles: true }))
      }
    }, 0)
  }

  const toggleLanguage = () => {
    setLanguage((prev) => (prev === "en" ? "ar" : "en"))
  }

  return (
    <div className={`h-screen bg-white flex flex-col ${isRTL ? "rtl" : "ltr"}`}>
      <div className="flex items-center justify-between p-3 border-b border-gray-100">
        <h1 className={`text-lg font-medium text-gray-900 ${isRTL ? "font-arabic" : ""}`}>{t.title}</h1>
        <Button variant="ghost" size="sm" onClick={toggleLanguage} className="text-gray-600 hover:text-gray-900">
          <Globe className="w-4 h-4 mr-1" />
          <span className="text-xs">{t.language}</span>
        </Button>
      </div>

      <div className="flex-1 overflow-hidden">
        {messages.length === 0 ? (
          <div className="h-full flex flex-col items-center justify-center">
            <div className="text-center mb-8">
              <h2 className={`text-3xl font-medium text-gray-900 mb-4 ${isRTL ? "font-arabic" : ""}`}>{t.title}</h2>
              <p className={`text-gray-500 ${isRTL ? "font-arabic" : ""}`}>{t.welcome}</p>
            </div>
            <div className="grid gap-2 w-full max-w-md px-4">
              {t.examples.map((example, index) => (
                <button
                  key={index}
                  onClick={() => handleExampleClick(example)}
                  className={`p-3 text-sm bg-gray-50 hover:bg-gray-100 rounded-lg transition-colors ${isRTL ? "font-arabic text-right" : "text-left"}`}
                >
                  {example}
                </button>
              ))}
            </div>
          </div>
        ) : (
          <div className="h-full overflow-y-auto">
            {messages.map((message) => (
              <div key={message.id} className={`py-6 ${message.role === "user" ? "bg-gray-50" : "bg-white"}`}>
                <div className="max-w-3xl mx-auto px-4">
                  <div className="flex gap-4">
                    <div
                      className={`w-8 h-8 rounded-sm flex items-center justify-center text-white text-sm font-medium ${message.role === "user" ? "bg-green-600" : "bg-gray-800"}`}
                    >
                      {message.role === "user" ? "U" : "ر"}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className={`text-gray-900 leading-relaxed ${isRTL ? "font-arabic" : ""}`}>{message.content}</p>
                    </div>
                  </div>
                </div>
              </div>
            ))}
            {isLoading && (
              <div className="py-6 bg-white">
                <div className="max-w-3xl mx-auto px-4">
                  <div className="flex gap-4">
                    <div className="w-8 h-8 rounded-sm flex items-center justify-center bg-gray-800 text-white text-sm font-medium">
                      ر
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex gap-1">
                        <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                        <div
                          className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"
                          style={{ animationDelay: "0.1s" }}
                        ></div>
                        <div
                          className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"
                          style={{ animationDelay: "0.2s" }}
                        ></div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      <div className="border-t border-gray-100 p-4">
        <div className="max-w-3xl mx-auto">
          <form onSubmit={handleSubmit} className="relative">
            <Input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder={t.placeholder}
              className={`w-full pr-12 py-3 border border-gray-200 rounded-lg focus:border-green-500 focus:ring-1 focus:ring-green-500 ${isRTL ? "font-arabic text-right pl-12 pr-4" : "pl-4"}`}
              dir={isRTL ? "rtl" : "ltr"}
              disabled={isLoading}
            />
            <Button
              type="submit"
              size="sm"
              className={`absolute top-1/2 -translate-y-1/2 ${isRTL ? "left-2" : "right-2"} h-8 w-8 p-0 bg-green-600 hover:bg-green-700 rounded-md`}
              disabled={!input.trim() || isLoading}
            >
              <Send className="w-4 h-4" />
            </Button>
          </form>
        </div>
      </div>
    </div>
  )
}
