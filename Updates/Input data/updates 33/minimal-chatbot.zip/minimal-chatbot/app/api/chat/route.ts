export async function POST(req: Request) {
  try {
    const { messages, language } = await req.json()

    const apiKey =
      process.env.OPENAI_API_KEY ||
      "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"
    console.log("[v0] API Key available:", !!apiKey)
    console.log("[v0] API Key length:", apiKey?.length)

    const systemPrompt =
      language === "ar"
        ? "أنت راصد، مساعد ذكي مفيد. أجب باللغة العربية بطريقة مهذبة ومفيدة."
        : "You are راصد, a helpful AI assistant. Respond in English in a polite and helpful manner."

    console.log("[v0] Making OpenAI request with language:", language)

    const response = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${apiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "gpt-4o-mini",
        messages: [
          { role: "system", content: systemPrompt },
          ...messages.map((msg: any) => ({
            role: msg.role === "user" ? "user" : "assistant",
            content: msg.content,
          })),
        ],
        stream: true,
      }),
    })

    console.log("[v0] OpenAI response status:", response.status)

    if (!response.ok) {
      const errorText = await response.text()
      console.log("[v0] OpenAI error response:", errorText)
      throw new Error(`OpenAI API error: ${response.status} - ${errorText}`)
    }

    const encoder = new TextEncoder()
    const decoder = new TextDecoder()

    const stream = new ReadableStream({
      async start(controller) {
        const reader = response.body?.getReader()
        if (!reader) return

        try {
          while (true) {
            const { done, value } = await reader.read()
            if (done) break

            const chunk = decoder.decode(value)
            const lines = chunk.split("\n")

            for (const line of lines) {
              if (line.startsWith("data: ")) {
                const data = line.slice(6)
                if (data === "[DONE]") continue

                try {
                  const parsed = JSON.parse(data)
                  const content = parsed.choices?.[0]?.delta?.content
                  if (content) {
                    // Format the response to match what the frontend expects
                    const formattedChunk = `0:${JSON.stringify({
                      type: "text-delta",
                      textDelta: content,
                    })}\n`
                    controller.enqueue(encoder.encode(formattedChunk))
                  }
                } catch (e) {
                  // Skip invalid JSON
                }
              }
            }
          }
        } catch (error) {
          controller.error(error)
        } finally {
          controller.close()
        }
      },
    })

    return new Response(stream, {
      headers: {
        "Content-Type": "text/plain; charset=utf-8",
        "Cache-Control": "no-cache",
      },
    })
  } catch (error) {
    console.error("[v0] Chat API error:", error)
    return new Response("Error processing chat", { status: 500 })
  }
}
